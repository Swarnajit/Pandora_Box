package walletHub;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class facebooklogin {
	Map<String,Object> prefs=new HashMap<String,Object>();
	ChromeOptions op=new ChromeOptions();
	Properties prop=new Properties();
	String baseUrl="https://www.facebook.com";
	WebDriver driver;
  @BeforeTest
  public void webBrowser()
  {
	  prefs.put("profile.default_content_setting_values.notifications", 2);
	  op.setExperimentalOption("prefs", prefs);
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\workspace\\facebooklogin\\drivers\\chromedriver.exe");
	  driver=new ChromeDriver(op);
	  File file=new File("C:\\Users\\User\\workspace\\facebooklogin\\src\\userdata.properties");
	  FileInputStream fi=null;
	  try {
		fi=new FileInputStream(file);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  try {
		prop.load(fi);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  @Test
  public void facebookLogin() throws NoSuchElementException {
	  driver.get(baseUrl);	  
	  driver.manage().window().maximize();
	  try {
		  driver.findElement(By.xpath("//*[@id='email']")).sendKeys(prop.getProperty("username"));
		  driver.findElement(By.xpath("//*[@id='pass']")).sendKeys(prop.getProperty("password"));
		  driver.findElement(By.id("loginbutton")).submit();
	  }
	  catch(NoSuchElementException ex) {
		  ex.printStackTrace();
	  }
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  try {
		  driver.findElement(By.cssSelector("._4bl9._42n-")).click();
		  driver.findElement(By.className("_5yk2")).sendKeys("Hello World");
		  driver.findElement(By.cssSelector("._1mf7._4jy0._4jy3._4jy1._51sy.selected._42ft")).click();
	  }
	  catch(NoSuchElementException newex) {
		  newex.printStackTrace();
	  }
  }
  @AfterTest
  public void logout() throws InterruptedException
  {
	  try {
	  driver.findElement(By.linkText("Account Settings")).click();
	  Thread.sleep(5000);
	  driver.findElement(By.linkText("Log out")).click();
	  Thread.sleep(5000);
	  driver.quit();
	}
	  catch(NoSuchElementException newex) {
		  newex.printStackTrace();
	  }
  }
}
