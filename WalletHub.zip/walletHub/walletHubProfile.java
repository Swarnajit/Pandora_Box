package walletHub;

import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class walletHubProfile {
@Test
  public void profile() throws InterruptedException {
	  Properties prop=new Properties();
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\workspace\\facebooklogin\\drivers\\chromedriver.exe");
	  WebDriver newdriver=new ChromeDriver();
	  WebDriverWait wait=new WebDriverWait(newdriver,10000);
	  newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  File file=new File("C:\\Users\\User\\workspace\\facebooklogin\\src\\userdata.properties");
	  FileInputStream fi=null;
	  try {
		fi=new FileInputStream(file);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  try {
		prop.load(fi);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  try{
		  newdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  newdriver.get("http://wallethub.com/profile/test_insurance_company/");
		  newdriver.manage().window().maximize();
		  newdriver.findElement(By.className("login")).click();
		  newdriver.findElement(By.name("em")).sendKeys("anandita.das96@gmail.com");
		  newdriver.findElement(By.name("pw")).sendKeys("Jhilam@1992");
		  newdriver.findElement(By.cssSelector(".toggle.inline-block.small")).click();
		  newdriver.findElement(By.cssSelector(".btn.blue.touch-element-cl")).submit();
		  wait.until(ExpectedConditions.visibilityOf(newdriver.findElement(By.cssSelector(".wh-rating.rating_5"))));
		  Actions action=new Actions(newdriver);
		  action.moveToElement(newdriver.findElement(By.cssSelector(".wh-rating.rating_5"))).perform();
	  //for(int i=1;i<=5;i++)
	  //{
		//  action.click(newdriver.findElement(By.linkText("i"))).perform();
	  //}
		  action.click(newdriver.findElement(By.linkText("5"))).build().perform();
		  newdriver.findElement(By.className("dropdown-list-new")).click();
		  newdriver.findElement(By.linkText("Health")).click();
		  Thread.sleep(2000);
		  newdriver.findElement(By.name("review")).click();
		  newdriver.findElement(By.name("review")).sendKeys(prop.getProperty("review"));
		  Thread.sleep(5000);
		  newdriver.findElement(By.className("btn.blue")).submit();
	  //WebElement element=newdriver.findElement(By.className("drop-el"));
	  //Select dropdown=new Select(element);
	  //dropdown.selectByVisibleText("Health");
		  Thread.sleep(5000);
		  newdriver.quit();
  }
	  catch(Exception ex)
	  {
		  System.out.println("Profile is not succesfully created, A "+ex.getMessage()+" is thrown");
	  }
}
}