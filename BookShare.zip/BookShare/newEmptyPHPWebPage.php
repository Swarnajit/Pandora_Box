<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link href="CSS/bootstrap.min.css.css" rel="stylesheet">

    </head>
    <body>
        
      <form action="newfilm.php" method="post" enctype="multipart/form-data">
          <center><h1 style="color: #ce3a3c">Submit a Short</h1></center>
              <h3>Name</h3>
          <input type="text" name="name" style="width: 50%" required autofocus>
          <h3>Author</h3>
          <input type="text" name="author" style="width: 50%" required autofocus>
          <h3>About</h3>
        <textarea name="about" style="width: 50%" required placeholder="Enter description here..."></textarea>
          <h3>Language</h3>
          <input type="text" name="language" style="width: 50%" required autofocus>
                    <h3>Comment</h3>
          <input type="text" name="comment" style="width: 50%" required autofocus>
                    <h3>Tags</h3>
          <input type="text" name="tags" style="width: 50%" required autofocus>
     <h3>Select image to upload:</h3>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <!--<input type="submit" value="Upload Image" name="submit">-->
     <br><br>
     <input type="submit" style="color: #cc0000;height: 40px;width: 100px;font-size: 20px;font-family: 'Arial'">

</form>
       
       
    </body>
</html>
