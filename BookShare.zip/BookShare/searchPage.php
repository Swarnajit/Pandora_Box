<?php
session_start();
require_once 'Database.php';
//require_once 'webFrame.php';
$choice=$_GET["booksearch"];
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>GetBookOnline- Online Library and Book rent</title>

    <!-- Bootstrap core CSS -->
    <link href="CSS/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="CSS/carousel.css" rel="stylesheet">
    <link href="CSS/blog.css" rel="stylesheet">
    <link href="CSS/formStyle.css" rel="stylesheet">
  </head>
  <body>
      
    <main role="main">
	
	<!--header added-->
	<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
            <a class="navbar-brand" href="index.php">Booken</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="Fiction">Fiction <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Horror</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">BestSellers</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Academic</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Self-Help</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Request</a>
          </li>
          <?php
            if(isset($_SESSION["Name"]))
            {    
          ?>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION["Name"]?></a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                  <a class="dropdown-item" href="newProfile.php">Profile</a>
                  <a class="dropdown-item" href="settings.php">Settings</a>
              <a class="dropdown-item" href="destroy">Logout</a>
            </div>
          </li>
          
          <?php
            }
          else
          {
           ?>
          <li class="nav-item active">
              <a class="nav-link" href="Login">Login</a>
          </li>
          <?php
          }
          ?>
        </ul>
          <div class="nav-item">
              <a href="#login-box" class="login-window"><img src="search-icon-png-27.png" height="30" width="30" alt="Search" title="Search"></a>
        	</div>
      </div>
    </nav>
	<!--Search form-------------->
        <div id="login-box" class="login-popup">
        <a href="#" class="close"><img src="close_pop.png" class="btn_close" title="Close Window" alt="Close" /></a>
        <form method="get" class="signin" action="searchPage.php">
                <fieldset class="textbox">
            	<label class="username">
                    <input id="booksearch" name="booksearch" value="" type="text" autocomplete="off" placeholder="Search your book in our library" onkeyup="showHint(this.value)">
                    
                </label>
                
                </fieldset>
            <div id="livesearch"></div>
          </form>
		</div>
        <br>
        <br>
              <div class="container marketing">
        <!-- Example row of columns -->
        <div class="row">
<?php
if(!empty($choice))
{
    $sqlquery="Select * from bookinfo where Book_Name like '%".$choice."%' or Author like '%".$choice."%' limit 10";
    $result= $conn->query($sqlquery);
    $num=mysqli_num_rows($result);
    if($num==0)
        {
    //echo 'Invalid phone number password combination';
            $flag=1;
    
        }
            else {
            while($row = mysqli_fetch_assoc($result)) 
            {
            ?>

        <div class="col-lg-4">
              <h2><?php echo $row['Book_Name'];?></h2>
			<img class="square" src="<?php echo "images/".$row['BookImage'];?>" alt="Generic placeholder image" width="150" height="200">
            <p><?php echo $row['Author'];?></p>            
            <p><form action="order.php" method="get">
                <input type="hidden" value="<?php echo $row['Book_ID']; ?>" name="hideed">
                <button class="btn btn-primary" type="submit" role="button">Request &raquo;</button>
            </form> 
          </div> 
<?php
                }
    }
}else
    header("Location:pricing.html");//.....error 404 page not found
    ?>
                    </div>
      </div>
        <?php
include 'webFrame.php';
?>
    </main>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="JS/jquery.min.js"><\/script>')</script>
    <script src="JS/popper.min.js"></script>
    <script src="JS/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="JS/holder.min.js"></script>
    <script src="JS/compressed.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
  </body>
</html>