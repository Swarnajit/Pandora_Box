<style>
    .div{
        font-family: 'Times New Roman';
            }
.footclass
{
    text-align: right;
    margin-left: 25px;
}
</style>   
<br>
<br>
<hr align="left" width="100%">
<footer class="container">
        <div class="row">
        <div class="col-lg-3">
                <ul class="footer-style">
                    <p style="font-size:150%">About Us</p>
        <p><a href="#">FAQ</a></p>
        <p><a href="#">How it Works</a></p>
      </ul>
            </div>
            <div class="col-lg-3">
                <ul class="footer-style">
          <p style="font-size:150%">Join Us</p>
        <p><a href="#">Want to work</a></p>
        <p><a href="#">Contribute</a></p>
      </ul>
            </div>
        <div class="col-lg-3">
                <ul class="footer-style">
                    <p style="font-size:150%">Media</p>
                    <p><a href="#">Facebook</a></p>
                    <p><a href="#">Instagram</a></p>
                    <p><a href="#">Pinterest</a></p>
      </ul>
            </div>
            <div class="col-lg-3">
                <ul class="footer-style">
          <p style="font-size:150%">Why Us</p>
        <p>&copy; 2018 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </ul>
            </div>
        </div>
    <hr align="center" width="100%">
    <div class="footclass">
    <a href="https://www.facebook.com/bitsniperz/"><img class="footclass" height="25" width="25" src="images/icon_share_facebook.png"></a>
    <a href="https://www.instagram.com"><img class="footclass" height="25" width="25" src="images/social-icon-instagram.png"></a>
    <a href="https://www.twitter.com/"><img class="footclass" height="25" width="25" src="images/twitter-bird.png"></a>
    <a href="https://www.pinterest.com/"><img class="footclass" height="25" width="25" src="images/icon-pinterest-red-white-50.png"></a>
    </div>    
    <hr align="center" width="100%">
      </footer>
