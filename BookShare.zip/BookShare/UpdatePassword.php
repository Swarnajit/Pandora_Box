
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
require_once 'Database.php';
if(isset($_SESSION["id"]))
{
    $choice=$_REQUEST["OldPassword"]; //value comes from videos.php
    $pass=$_REQUEST["NewPassword"]; //value comes from videos.php
    //echo "fdsfdsfsdjhfsdjhfshfd";
    $sqlquery1="Select fname from people where password='".$choice."' and user_id='".$_SESSION["id"]."'";
    $result1= $conn->query($sqlquery1);
    $num=mysqli_num_rows($result1);
    if($num!=0)
    {
        $sqlquery2="UPDATE people SET password='".$pass."' WHERE user_id='".$_SESSION["id"]."'";
        $result= $conn->query($sqlquery2);
        if($result)
            echo 'Successful';
        else {
            echo 'Not Successful';
        }
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
}
else
    echo "Wrong Password";
}
//echo 'abcdefghijk';
    ?>
