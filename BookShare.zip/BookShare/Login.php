<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Login or Signup</title>

    <!-- Bootstrap core CSS -->
    <link href="CSS/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="CSS/signin.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">
        <form class="form-signin" action="checkprofile.php" method="post" enctype="multipart/form-data">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputEmail" class="sr-only">Phone Number</label>
        <input id="inputEmail" name="number" class="form-control" placeholder="Phone Number" required autofocus>
        <input id="inputPassword" name="password1" type="password" class="form-control" placeholder="Password" required autofocus>
        <button class="btn btn-lg btn-primary btn-block" type="button" onclick="profileCheck()">Sign in</button>
      </form>
        
    </div> <!-- /container -->
    <script>
    function profileCheck()
{
         var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML = this.responseText;
      if(this.responseText==1)
          window.alert(window.location.href);
      else if(this.responseText==3)
      window.alert("Already Logged In");
  else
      {
       setTimeout(function() {
           window.location.href="index.php";
  //window.location.href = window.location.hostname;
}, 3000);
      } 
    }
  };
  var str1=document.getElementById("inputEmail").value;
  var str2=document.getElementById("inputPassword").value;
  xhttp.open("POST", "checkprofile.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("number="+str1+"&password1="+str2);
}</script>
  </body>
</html>

