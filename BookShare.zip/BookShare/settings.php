<?php
session_start();
require_once 'Database.php';
//include 'webFrame.php';
if(isset($_SESSION["id"]))
{
    $choice=$_SESSION["id"]; //value comes from videos.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Settings Page</title>
  <meta name="description" content="Responsive tabbed layout component built with some CSS3 and JavaScript">
  <link rel="stylesheet" href="CSS/style.min.css">
      <link href="CSS/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="CSS/blog.css" rel="stylesheet">
    <link href="CSS/formStyle.css" rel="stylesheet">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="icon" href="Graphicloads-Colorful-Long-Shadow-Book.ico">
  <style>
      .form-control
      {
          margin-left: 25%;
          width: 50%;
      }
  </style>
</head>
<body>
	
	<!--header added-->
	<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
            <a class="navbar-brand" href="index.php">Booken</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="Fiction">Fiction <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Horror</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">BestSellers</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Academic</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Self-Help</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Request</a>
          </li>
          <?php
            if(isset($_SESSION["Name"]))
            {    
          ?>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION["Name"]?></a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                  <a class="dropdown-item" href="newProfile.php">Profile</a>
                  <a class="dropdown-item" href="settings.php">Settings</a>
              <a class="dropdown-item" href="destroy">Logout</a>
            </div>
          </li>
          
          <?php
            }
          else
          {
           ?>
          <li class="nav-item active">
              <a class="nav-link" href="Login">Login</a>
          </li>
          <?php
          }
          ?>
        </ul>
          <div class="nav-item">
              <a href="#login-box" class="login-window"><img src="search-icon-png-27.png" height="30" width="30" alt="Search" title="Search"></a>
        	</div>
      </div>
    </nav>
	<!--Search form-------------->
        <div id="login-box" class="login-popup">
        <a href="#" class="close"><img src="close_pop.png" class="btn_close" title="Close Window" alt="Close" /></a>
        <form method="get" class="signin" action="searchPage.php">
                <fieldset class="textbox">
            	<label class="username">
                    <input id="booksearch" name="booksearch" value="" type="text" autocomplete="off" placeholder="Search your book in our library" onkeyup="showHint(this.value)">
                    
                </label>
                
                </fieldset>
            <div id="livesearch"></div>
          </form>
		</div>
  <main class="o-main">
  <div class="o-container">

    <div class="o-section">
      <div id="tabs" class="c-tabs no-js">
        <div class="c-tabs-nav">
		  <a href="#" class="c-tabs-nav__link is-active">
            <i class="fa fa-cog"></i>
            <span>Details</span>
          </a>
          <a href="#" class="c-tabs-nav__link">
            <i class="fa fa-home"></i>
            <span>Password</span>
          </a>
          <a href="#" class="c-tabs-nav__link">
            <i class="fa fa-book"></i>
            <span>Address</span>
          </a>
          <a href="#" class="c-tabs-nav__link">
            <i class="fa fa-heart"></i>
            <span>Phone</span>
          </a>
          <a href="#" class="c-tabs-nav__link">
            <i class="fa fa-calendar"></i>
            <span>Email</span>
          </a>
        </div>
        <div class="c-tab is-active">
          <div class="c-tab__content">
            <h2>Welcome home!</h2>
            <p>Home ipsum dolor sit amet, consectetur adipisicing elit. Ipsam quo minus voluptate unde tempore eveniet consequuntur in, quod animi libero rem similique pariatur quos, et eum nisi ducimus, architecto voluptatibus!</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto aspernatur natus dolorem fuga cumque optio saepe corrupti earum. Ipsam quaerat asperiores similique omnis excepturi temporibus ab eum magnam ipsa, odio.</p>
          </div>
        </div>
        <div class="c-tab">
            <div class="c-tab__content">
            <h2>Update Password</h2>
            <input id="inputOldPassword" name="inputOldPassword" type="password" class="form-control" placeholder="Password" autocomplete="off" required>
            <input id="inputPassword" name="inputPassword" type="password" class="form-control" placeholder="New Password" autocomplete="off" onkeyup="check();" required>
            <input id="confirmPassword" name="confirmPassword" type="password" class="form-control" placeholder="Confirm Password" autocomplete="off" onkeyup="check();" required>
            <br>
            <button style="margin-left: 25%" disabled class="btn btn-primary" id="abcd" type="submit" onclick="passwordChange()">Change Password</button>
          </div>
        </div>
        <div class="c-tab">
          <div class="c-tab__content">
            <h2>Add Address</h2>
            <textarea id="address" style="resize:none;height: 25%" name="AddAddress" class="form-control" placeholder="Address" required></textarea>
            <input id="pincode" name="AddPincode" type="text" class="form-control" placeholder="Pincode" autocomplete="off" required>
            <br>
            <button style="margin-left: 25%" class="btn btn-primary" type="submit" onclick="addressUpdate()">Update</button>
          </div>
        </div>
        <div class="c-tab">
          <div class="c-tab__content">
            <h2>Add Phone</h2>
            <form id="signin" class="form-signin" action="profile.php" method="post" enctype="multipart/form-data">
                <input id="oldPhone" name="oldPhone" type="text" class="form-control" value="9804306974" readonly autocomplete="off">
            <input id="newPhone" name="newPhone" type="text" class="form-control" placeholder="New Number" autocomplete="off" required>
            <button id="verifyButton" style="margin-left: 25%" class="btn btn-primary" onclick="checkPhone();">Verify</button>
            <br>
            <input id="OTP" name="OTP" style="margin-left: 25%" type="password" hidden class="form-control" placeholder="Put OTP here" autocomplete="off" required>
            <br>
            <button id="submitButton" style="margin-left: 25%" class="btn btn-primary" type="submit" disabled>Update Contact</button>
            </form>
          </div>
        </div>
        <div class="c-tab">
          <div class="c-tab__content">
            <h2>Change It Up</h2>
            <p>Settings ipsum dolor sit amet, consectetur adipisicing elit. Ipsam quo minus voluptate unde tempore eveniet consequuntur in, quod animi libero rem similique pariatur quos, et eum nisi ducimus, architecto voluptatibus!</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto aspernatur natus dolorem fuga cumque optio saepe corrupti earum. Ipsam quaerat asperiores similique omnis excepturi temporibus ab eum magnam ipsa, odio.</p>
          </div>
        </div>
      </div>
    </div>
<!--Footer Class-->
  </div>
      <?php
include_once 'webFrame.php';
?>
<!--Footer Ends here-->
</main>

    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="JS/jquery.min.js"><\/script>')</script>
    <script src="JS/popper.min.js"></script>
    <script src="JS/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="JS/holder.min.js"></script>
    <script src="JS/tabs.js"></script>
    <script src="JS/compressed.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script>
  var myTabs = tabs({
    el: '#tabs',
    tabNavigationLinks: '.c-tabs-nav__link',
    tabContentContainers: '.c-tab'
  });

  myTabs.init();
</script>
</body>
</html>
<?php
}
 else {
    header("Location:pricing.html");    
}
?>
