
<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
$temp=0;
if(isset($_SESSION["Name"]))
{   
    require_once 'Database.php';
    $lovely=$_POST["pagla"];//....................use some filtering function
    $checksql="select plan from people where user_id='".$lovely."'";
    $checkresult= $conn->query($checksql);
    $num1=mysqli_num_rows($checkresult);
    if($num1!=0)
        {
            while($row= mysqli_fetch_assoc($checkresult))
            {
                //echo $num1;
                if(is_null($row['plan']))
                    //header ("Location:pricing.html");
                        $temp=1;
            }
        }
        if($temp!=1)
        {
                    if(isset($_POST["hideed"]))
    {    
        $choice1= base64_decode($_POST["hideed"]); //coming from order.php
//echo $choice1;
//echo $lovely;
$status="passed";
date_default_timezone_set('Asia/Kolkata');
$mydate=date('Y-m-d H:i:s');
$checksql="select order_date from order_handler where book_id='".$choice1."' and user_id='".$lovely."'";
$checkresult= $conn->query($checksql);
$num1=mysqli_num_rows($checkresult);
if($num1==0)//.................check if the order is given in the same month
{
   $sqlquery="insert into order_handler (book_id,user_id,status,order_date) values ('$choice1','$lovely','$status','$mydate')";
    $result= $conn->query($sqlquery);
    if($result==TRUE)
        echo 'your order is confirmed';
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
//$num=mysqli_num_rows($result); 
//if(strlen($newchoice)==6)
//{
  //  $preparequery="insert into order_handler(book_id,user_id,status,order_date) values ('$choice1','$newchoice')";
    //$newresult=$conn->query($preparequery);
   // echo "naaaaice";
//}    
}
else
    echo 'Already Ordered';
}
 
}else {
    echo 'You have not subscribed to any plan';
    }

        }
    
else
    header("Location: SignUp_Password.php");
    //include 'SignUp.php';//............................Page Not found Error 404
?>
