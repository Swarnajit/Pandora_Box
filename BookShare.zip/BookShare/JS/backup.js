/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function showHint(str) {
    if (str.length == 0) { 
        document.getElementById("livesearch").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("livesearch").innerHTML =this.responseText;
                
            }
        };
        xmlhttp.open("GET", "gethint.php?q=" + str, true);
        xmlhttp.send();
    }
}
        
var check = function() {
        var inputPassword=document.getElementById('inputPassword');
        var confirmPassword=document.getElementById('confirmPassword');
        var newbutton=document.getElementById('abcd');
  if (inputPassword.value ===
    confirmPassword.value){
    newbutton.disabled =false;
    newbutton.innerHTML="Change Password";
  } else {
    newbutton.disabled=true;
    newbutton.innerHTML="Password not matched";
  }
}
function checkPhone()
{
    var newPhone=document.getElementById('newPhone').value;
    if(newPhone.length===10)
    {
        document.getElementById('OTP').hidden=false;
        document.getElementById('submitButton').disabled=false;
        document.getElementById('verifyButton').hidden=true;
    }
    else
    {
        document.getElementById('OTP').hidden=true;
        document.getElementById('submitButton').disabled=true;
    }
}
$(document).ready(function() {
	$('a.login-window').click(function() {
		
		// Getting the variable's value from a link 
		var loginBox = $(this).attr('href');

		//Fade in the Popup and add close button
		$(loginBox).fadeIn(300);
		
		//Set the center alignment padding + border
		var popMargTop = ($(loginBox).height() + 24) / 2; 
		var popMargLeft = ($(loginBox).width() + 24) / 2; 
		
		$(loginBox).css({ 
			'margin-top' : -popMargTop,
			'margin-left' : -popMargLeft
		});
		
		// Add the mask to body
		$('body').append('<div id="mask"></div>');
		$('#mask').fadeIn(300);
		
		return false;
	});
	
	// When clicking on the button close or the mask layer the popup closed//
	$('a.close, #mask').live('click', function() { 
	  $('#mask , .login-popup').fadeOut(300 , function() {
		$('#mask').remove();  
	}); 
	return false;
	});
});
function delBook(str)
{
    //var bookinfo=str;
    //alert(bookinfo);
    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText);
                location.reload();
                
            }
        };
        xmlhttp.open("GET", "delete.php?q=" + str, true);
        xmlhttp.send();
}
function passwordChange()
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML = this.responseText;
      window.alert(this.responseText);
      document.getElementById("inputOldPassword").reset();
      document.getElementById("inputPassword").reset();
        }
    };
    var str1=document.getElementById("inputOldPassword").value;
    var str2=document.getElementById("inputPassword").value;
    xhttp.open("POST", "UpdatePassword.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("OldPassword="+str1+"&NewPassword="+str2);
}
function addressUpdate()
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML = this.responseText;
      window.alert(this.responseText);
      document.getElementById("address").reset();
      var str2=document.getElementById("pincode").reset();
        }
    };
    var str1=document.getElementById("address").value;
    var str2=document.getElementById("pincode").value;
    xhttp.open("POST", "UpdateAddress.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("address="+str1+"&pincode="+str2);
}