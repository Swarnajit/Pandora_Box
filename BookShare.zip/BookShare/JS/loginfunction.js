/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function profileCheck()
{
         var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML = this.responseText;
      if(this.responseText==1)
          window.alert("asadhhhhhhhhhgsdasgdsdbsbdshbhdshdbhsd");
      else
      {
       setTimeout(function() {
  window.location.href = "index.php";
}, 3000);
      } 
    }
  };
  var str1=document.getElementById("inputEmail").value;
  var str2=document.getElementById("inputPassword").value;
  xhttp.open("POST", "checkprofile.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("number="+str1+"&password1="+str2);
}


