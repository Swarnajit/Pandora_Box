
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
$host="localhost";
$username="root";
$password="tiger";
$dbname="bookshare";
$choice=$_SESSION["id"]; //value comes from videos.php
//echo $choice;
$conn=  mysqli_connect($host, $username, $password, $dbname) or die("Cann not connect to database");
$sqlquery="select bookinfo.Book_Name,bookinfo.BookImage,bookinfo.Book_ID from bookinfo INNER JOIN order_handler
ON order_handler.Book_ID=bookinfo.Book_ID where order_handler.user_id='".$choice."'";
$result= $conn->query($sqlquery);
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
$num=mysqli_num_rows($result);
if($num==0)
    echo '<html>'
    . '<body>'
        . 'You have not ordered anything yet'
        .'</body>'
        .'</html>';
    else {
        while($row = mysqli_fetch_assoc($result)) 
        {
            ?>
<div class="col-lg-4">
              <h2><?php echo $row['Book_Name'];?></h2>
			<img class="square" src="<?php echo $row['BookImage'];?>" alt="Generic placeholder image" width="150" height="200">
            <p><form action="order.php" method="get">
                <input type="hidden" value="<?php echo $row['Book_ID']; ?>" name="hideed">
                <button class="btn btn-primary" type="submit" role="button">About &raquo;</button>
            </form> 
          </div>  
<?php
        }
    }
    ?>
