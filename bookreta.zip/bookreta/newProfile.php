<?php
session_start();
require_once 'Database.php';
$i=1;
if(isset($_SESSION["id"]))
{
    $choice=$_SESSION["id"]; 
//echo $choice;
//$livesearch="dfsdfsdfsdfsd";
$sqlquery="select bookinfo.Book_Name,bookinfo.BookImage,bookinfo.Book_ID,order_handler.order_date,order_handler.book_status,order_handler.order_id from bookinfo INNER JOIN order_handler
ON order_handler.Book_ID=bookinfo.Book_ID where order_handler.user_id='".$choice."' ORDER BY order_date DESC";
$result= $conn->query($sqlquery);
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
$num=mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Profile of <?php echo $_SESSION["Name"];?></title>

    <!-- Bootstrap core CSS -->
    <style>
  .unstyled-button {
  border: none;
  padding: 0;
  color: blue;
  background: none;
}
        
    </style>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <link href="css/blog.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <script src="javascript/ie-emulation-modes-warning.js"></script>
  </head>       
  <body>
               
      <div class="container">
          <!-- Fixed navbar -->
          <header class="blog-header py-3">
                        <?php
        include 'header.php';
        ?>
              <br>
              <br>

          </header>        
          <div class="jumbotron p-3 p-md-5 text-white rounded bg-dark">
            <div class="col-md-6 px-0">
                

  <!-- PasswordModal -->
  <div class="modal fade" id="passwordmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            
            <h4 class="modal-title" id="modalStatus" style="color:black"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

        </div>
        <div class="modal-body">
        <input id="inputOldPassword" name="inputOldPassword" type="password" class="form-control" placeholder="Current Password" required autofocus><br>
        <input id="inputPassword" name="inputPassword" type="password" class="form-control" placeholder="New Password" onkeyup="check();" required autofocus><br>
        <input id="confirmPassword" name="confirmPassword" type="password" class="form-control" placeholder="Confirm Password" onkeyup="check();" required autofocus><br>
        </div>
        <div class="modal-footer">
          <button type="button" class="close" id="abcd" onclick="passwordChange()">Submit</button>
        </div>
      </div>
      
    </div>
  </div><!-- UpdateModal -->
  <div class="modal fade" id="updatemodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="addressStatus" style="color:black"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

        </div>
        <div class="modal-body">
            <textarea id="address" style="resize:none;" name="AddAddress" class="form-control" placeholder="Address" required autofocus></textarea>
        <br>
        <input id="pincode" name="pincode" class="form-control" placeholder="PinCode" required ><br>
        <input id="newPhone" name="newPhone" class="form-control" placeholder="New Phone" required onkeyup="checkPhone();"><br>
        <input id="OTP" name="OTP" type="password" hidden class="form-control" placeholder="Put OTP here" autocomplete="off" required>
        </div>
        <div class="modal-footer">
            <button type="button" class="close" onclick="addressUpdate();">Submit</button>
        </div>
      </div>
      
    </div>
  </div>
  
            <?php
              $prepareQuery="Select fname,lname,address,phone,plan,Validity from people where user_id='".$choice."'";
              $result1=$conn->query($prepareQuery);
              $num1=mysqli_num_rows($result1);
              if($num1!=0)
              {
                  while($row1= mysqli_fetch_assoc($result1))
                    {
              ?>
          <h1 class="display-4 font-italic"><?php echo $row1['fname']." ".$row1['lname'];?></h1>
          <p class="lead my-3"><?php echo $row1['address'];?>
          <p class="lead my-3">Phone : <?php echo $row1['phone']; ?></p>
          <?php
          if(is_null($row1['plan']))
          {
          ?>
          	<p class="lead mb-0">You have not subscribed to any plan</p>
          <?php
          }
          else
          {
          ?>
          	<p class="lead mb-0">Subscriber of <strong><?php echo $row1['plan']; ?></strong> plan</p>
          <?php
          }
          if(is_null($row1['Validity']))
          {
          ?>
          	<p class="lead mb-0"></p>
          <?php
          }
          else
          {
          ?>	
          	<p class="lead mb-0">Plan valid till <strong><?php echo date('D,d M Y', strtotime($row1['Validity'])); ?></strong></p>
          <?php
          }
          ?>	
          <p class="lead my-3"><button class="btn" data-toggle="modal" data-target="#updatemodal">Update Profile</button></p>
          <p class="lead my-3"><button class="btn" data-toggle="modal" data-target="#passwordmodal">Change Password</button></p>
              <?php
                    }
              }
          ?>
        </div>
      </div>
            <?php
    if($num==0)
    echo '<html>'
    . '<body>'
        . 'You have not ordered anything yet'
        .'</body>'
        .'</html>';
    else {  
    ?>
      <div class="row mb-2">
                <?php
                while($row = mysqli_fetch_assoc($result)) 
                {       
                ?>
           <div class="col-md-6">
               <div class="card flex-md-row mb-4 box-shadow h-md-250">
                    <div class="card-body d-flex flex-column align-items-start">
                        <strong class="d-inline-block mb-2 text-primary"><?php echo $row['order_id'];?></strong>
                            <h3 class="mb-0">
                            <a class="text-dark" href="#"><?php echo $row['Book_Name'];?></a>
                            </h3>
                            <div class="mb-1 text-muted"><?php echo date('d-m-Y', strtotime($row['order_date']));?></div>
                            <p class="card-text mb-auto"><?php echo $row['book_status'];?></p>
                            <?php
                                date_default_timezone_set('Asia/Kolkata');
                                $date_now = date('Y/m/d H:i:s');
                                if ($date_now <= date('Y/m/d H:i:s', strtotime($row['order_date'] .'+24 hour')))
                                {
                                    ?>
                            <Button class="unstyled-button" onclick="delBook(this.value)" value="<?php echo $row['order_id'];?>">Delete</button>
                    <?php
                                }
                                ?>
                        
                    </div>
                    <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo 'images/'.$row['BookImage'];?>" alt="Card image cap">
                </div>
           </div>
         <?php
                 }
    }
                 ?>

        </div>
    </div>
<?php
        include 'footer.php';
        ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="JS/jquery.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Dont actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup_1.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
</body>
</html>
<?php
}
 else {
    header("Location:error_page");    
}
?>