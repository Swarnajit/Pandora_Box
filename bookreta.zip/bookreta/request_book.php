<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
$temp=0;
if(isset($_SESSION["Name"]))
{   
    require_once 'Database.php';
    $lovely=$_POST["pagla"];//....................use some filtering function
    $checksql="select plan from people where user_id='".$lovely."'";
    $checkresult= $conn->query($checksql);
    $num1=mysqli_num_rows($checkresult);
    if($num1!=0)
        {
            while($row= mysqli_fetch_assoc($checkresult))
            {
                switch ($row['plan']) {
                    case "Turtle":
                        $number_of_books=1;
                        break;
                    case "Rabbit":
                        $number_of_books=2;
                        break;
                    case "Cheetah":
                        $number_of_books=4;
                        break;
                    default:
                        break;
                }
                if(is_null($row['plan']))
                    header ("Location:error_page");
                        $temp=1;
            }
        }
        if($temp==1)
        {
                    if(isset($_POST["hideed"]))
                {    
        $choice1= base64_decode($_POST["hideed"]); //coming from order.php
//echo $choice1;
//echo $lovely;
$status="Active";
$order="A".rand(001, 999)."ERFG";
date_default_timezone_set('Asia/Kolkata');
$mydate=date('Y-m-d H:i:s');
$int=(int)date("m");
$checksql="select order_date from order_handler where book_id='".$choice1."' and user_id='".$lovely."'";
$checkresult= $conn->query($checksql);
$num1=mysqli_num_rows($checkresult);
if($num1==0)//.................check if the order is given in the same month
{
            $checkquery="Select order_id from order_handler where book_status='Active' and user_id='".$lovely."'";
            $newresult=$conn->query($checkquery);
            $bookNumber=mysqli_num_rows($newresult);
            if($bookNumber==$number_of_books)
            {
                echo 'You have reached your limit';
            }
            else
            {
                $_SESSION['order']=$order;
                $sqlquery="insert into order_handler (book_id,user_id,order_id,book_status,order_date) values ('$choice1','$lovely','$order','$status','$mydate')";
                $result= $conn->query($sqlquery);
                    if($result==TRUE)
                        header ("Location:request_success") ;
//echo 'your order is confirmed'.$choice1." on ".$mydate;
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
//$num=mysqli_num_rows($result); 
//if(strlen($newchoice)==6)
//{
  //  $preparequery="insert into order_handler(book_id,user_id,status,order_date) values ('$choice1','$newchoice')";
    //$newresult=$conn->query($preparequery);
   // echo "naaaaice";
//}    
            }
}
else{
    while($row = mysqli_fetch_assoc($checkresult))
    {
        if($int==(int)date("m",strtotime($row['order_date'])))
                echo "You can not order for this month";
        else
        { 
            $checkquery="Select order_id from order_handler where book_status='Active' and user_id='".$lovely."'";
            $newresult=$conn->query($checkquery);
            $bookNumber=mysqli_num_rows($newresult);
            echo $bookNumber;
            if($bookNumber==$number_of_books)
            {
                echo 'You have reached your limit';
            }
            else 
            {   
                $sqlquery="insert into order_handler (book_id,user_id,order_id,book_status,order_date) values ('$choice1','$lovely','$order','$status','$mydate')";
                $result= $conn->query($sqlquery);
                if($result==TRUE)
                header ("Location:request_success") ;                
            
            }
        
        //echo 'Already Ordered on '.(int)date("m",strtotime($row['order_date']));
    }
}
                }
                
    
}
 
}else {
    echo 'You have not subscribed to any plan';
    }

        }
    
else
    header("Location: SignUp_Password.php");
    //include 'SignUp.php';//............................Page Not found Error 404

?>
