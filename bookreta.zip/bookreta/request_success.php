<!DOCTYPE html>
<?php
session_start();
require_once 'Database.php';
//include 'webFrame.php';
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Bookreta- Online Library and Book rent</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/theme.css" rel="stylesheet">
    <link href="css/blog.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <style>
 .iconDetails {
    margin-left:2%;
    float:left; 
    height:15%;
    width:15%;	
    } 

.container2 {
	width:100%;
	height:auto;
	padding:1%;
        font-family: 'Times New Roman';
}
h1,h3,h4
{
    font-family: 'Times New Roman';
}
    </style>
  </head>
  <body>  
<main role="main">
        <?php
        include 'header.php';
    if((isset($_SESSION['order'])) && ($_SESSION['order']!=1))
    {
    ?>
    <div class="container">
       <div class="jumbotron mt-3">
            <div class="row featurette">
                <div class="col-md-7 order-md-2">
                    <br>
                    <h2 class="featurette-heading">Your book request is placed successfully!</h2>
                    
                    <h4 class="featurette-heading"><?php  echo $_SESSION["book"]."<br>";
                        date_default_timezone_set('Asia/Kolkata');
                        $deliverydate=date('Y-m-d', strtotime("+3 days"));?></h4>
                    <h4>Order Id:<?php echo $_SESSION['order'];?></h4>
                    <h4>Book Delivery expected by <strong><?php echo date('D,d M Y', strtotime($deliverydate));?></strong></h4>
                    <p><strong>Thank you!</strong> You can track your order through <a href="newProfile"><strong>Profile</strong></a> page.</p>
                </div>
                <div class="col-md-5 order-md-1">
                    <img class="featurette-image img-fluid mx-auto" src="<?php echo "images/".$_SESSION["bookimage"];?>" alt="Generic placeholder image">
                </div>
            </div>
       </div>
    </div>
<?php
    $_SESSION['order']=1;
    }
    else if($_SESSION['order']==1)
    {
        echo '<br><br><br><br><br><br>Check your order here';
    }
    else
    {
        echo 'error 404.html..........................page not found';
    }
include_once 'footer.php';
?>
</main>    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="JS/jquery.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="JS/holder.min.js"></script>
    <script src="JS/backup.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>

  </body>
</html>
