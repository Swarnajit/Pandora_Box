<?php
require_once 'Database.php';
// get the q parameter from URL
try
{
    //$q =$_REQUEST["q"];
    $q= filter_input(INPUT_GET, "q",FILTER_SANITIZE_SPECIAL_CHARS);
    $q= str_replace("%", "^", $q);
    

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $param="%{$q}%";
    $sqlquery=("select Book_Name,Book_ID from bookinfo where Book_Name like '%".$q."%' limit 5");//'%".$q."%'
    $result= $conn->query($sqlquery);
    $num=mysqli_num_rows($result);
    /*$sqlquery->bind_param('s',$param);
    $sqlquery->execute();
    $result= $conn->query($sqlquery);
    $num=mysqli_num_rows($result);*/
    if($num==0)
        {  
        $sqlquery="select DISTINCT Author from bookinfo where Author like '%".$q."%'";
        $result= $conn->query($sqlquery);
        $num=mysqli_num_rows($result);
            //exit;
        if($num==0)
        {  
            $hint = "<a style='color: #b3d7ff'>No Suggestion</a>";
        }
        else
            {
            while($row= mysqli_fetch_assoc($result))
            {
              $hint .= "<a href='searchPage?booksearch=".$row['Author']."' style='color: #b3d7ff'>".$row['Author']."</a><p style='color: #fff'>        in Author</p>";
            }
        }
        }
        else
        {
            while($row= mysqli_fetch_assoc($result))
            {
              $hint .= "<a href='order?hideed=".$row['Book_ID']."' style='color: #b3d7ff'>".$row['Book_Name']."</a><p style='color: #fff'>        in Books</p>";
            }
        }
}
 /*   foreach($a as $name) {
        if (stristr($q, substr($name, 0, $len))) {
            if ($hint === "") {
                $hint = "<a style='color: #b3d7ff'>".$name."</a>";
            } else {
                $hint .= "<br/><a style='color: #b3d7ff'>".$name."</a>";
            }
        }
    }
}*/

// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "<a style='color: #b3d7ff'>no suggestion</a>" : $hint;
}
 catch (Exception $e)
 {
    header("Location:error_page");//..........error 404 file
 }
?>