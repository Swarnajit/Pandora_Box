<?php
session_start();
require_once 'Database.php';
//include 'webFrame.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Error_Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/carousel.css" rel="stylesheet">
    <style>
.error {
    display: block;
    margin-left: auto;
    margin-right: auto;
    height: 10%;
    width: 40%;
}
    </style>
  </head>
  <body>
<header>
    <?php
    include 'header.php';
    ?>
    </header>  
    <main role="main">
<br>
        <br>
        
        <img class="error" src="images/267637-4afe7b833e63d05a85121ec04e68a608.jpg" alt="error details">   
        
        <?php
include 'footer.php';
?>
    </main>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="javascript/jquery-slim.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup.js"></script>
  </body>
</html>