
<?php
include 'Database.php';
$details= trim($_POST['order_id']);
$sqlquery="select bookinfo.Book_Name,bookinfo.BookImage,order_handler.order_date,order_handler.book_status from bookinfo INNER JOIN order_handler
ON order_handler.Book_ID=bookinfo.Book_ID where order_handler.order_id='".$details."'";
$result= $conn->query($sqlquery);
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
$num=mysqli_num_rows($result);
if($num!=0)
{ 
    while($row = mysqli_fetch_assoc($result)) 
    {       
        echo $row['Book_Name'];
        echo $row['book_status'];
    }
}
$sqlquery="select fname,lname,address from people where user_id=(select user_id from order_handler where order_id='".$details."')";
$result1= $conn->query($sqlquery);
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
$num1=mysqli_num_rows($result1);
if($num1!=0)
{ 
    while($row1 = mysqli_fetch_assoc($result1)) 
    {       
        echo $row1['fname'];
        echo $row1['lname'];
        echo $row1['address'];
    }
}
?>