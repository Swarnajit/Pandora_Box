<!doctype html>
<?php
session_start();
require_once 'Database.php';
//include 'webFrame.php';
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="google-site-verification" content="L8lV70c-9vexJr9C9iR995xDqkwc-KH1yz3h1_NZ94Q" />
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Bookreta - Online Library and Book rent</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/carousel_1.css" rel="stylesheet">
  </head>
  <body>

    <header>
    <?php
    include 'header.php';
    ?>
    </header>

    <main role="main">

      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
              <img class="first-slide" src="images/411522.jpg" alt="First slide">
            <div class="container">
              <div class="carousel-caption text-left">
                <h1>Welcome to Bookreta.</h1>
                <p>Sign up to become a member of the online library from the "City of JOY"</p>
                <p><a class="btn btn-lg btn-primary" href="SignUp_Password" role="button">Sign up today</a></p>
              </div>
            </div>
          </div>
            <div class="carousel-item">
              
              <div class="container">
              <div class="carousel-caption">
                <h1 style="color: black">Not Expensive</h1>
                <p style="color: whitesmoke">Get the facility to get and return books at your doorstep in affordable prices</p>
                <p><a class="btn btn-lg btn-primary" href="pricing.php" role="button">Check our price</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
              <img class="third-slide" src="images/newbook.jpg" alt="Third slide">
            <div class="container">
              <div class="carousel-caption text-right">
                <h1 style="color: black">Because Book is Love</h1>
                <p style="color: black">Meet your friend, philosopher and guide through us</p>
                <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
              </div>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>


      <!-- Marketing messaging and featurettes
      ================================================== -->
      <!-- Wrap the rest of the page in another container to center all the content. -->

      <div class="container marketing">

        <!-- Three columns of text below the carousel -->
        <div class="row">
            <?php
       $sqlquery="select * from bookinfo limit 10";
        $result= $conn->query($sqlquery);
 //mysqli_query($conn,$sqlquery);
//$row = mysql_fetch_assoc($result); 
        $num=mysqli_num_rows($result);
       if($num==0)
        {
            echo "No record";
            //exit;
        }
        else
        {
            while($row= mysqli_fetch_assoc($result))
            {
            ?>
          <div class="col-lg-4">
              <h5><?php echo $row['Book_Name'];?></h5>
            <img class="square" src="<?php echo "images/".$row['BookImage'];?>" alt="<?php echo $row['Book_Name'];?>" width="150" height="200">  
            <p><form action="order.php" method="get">
                <input type="hidden" value="<?php echo $row['Book_ID']; ?>" name="hideed">
                <button class="btn btn-primary" type="submit" role="button">Request &raquo;</button>
            </form>
          </div><!-- /.col-lg-4 -->
         <?php
            }
        }
        ?>
        </div><!-- /.row -->


        <!-- START THE FEATURETTES -->

        <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading">Dan Brown Series</h2>
            <p class="lead">If you are fond of conspiracy theories and know who Robert Langdon is, this is your playground.</p>
          </div>
          <div class="col-md-5">
              <img class="featurette-image img-fluid mx-auto" src="images/Desktop4.jpg" alt="Generic placeholder image">
          </div>
        </div>

        <hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7 order-md-2">
            <h2 class="featurette-heading">Sherlock Holmes<span class="text-muted"></span></h2>
            <p class="lead">The best detective in the world. Explore the crime world of Victorian England with his creator Sir Arthur Conan Doyle through these awesome books.</p>
          </div>
          <div class="col-md-5 order-md-1">
              <img class="featurette-image img-fluid mx-auto" src="images/sherlock books.png" alt="Generic placeholder image">
          </div>
        </div>

        <!--<hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading">And lastly, this one. <span class="text-muted">Checkmate.</span></h2>
            <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
          </div>
          <div class="col-md-5">
            <img class="featurette-image img-fluid mx-auto" data-src="holder.js/500x500/auto" alt="Generic placeholder image">
          </div>
        </div>-->

        <hr class="featurette-divider">

        <!-- /END THE FEATURETTES -->

      </div><!-- /.container -->


      <!-- FOOTER -->
<?php
        include 'footer.php';
?>
    </main>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="javascript/jquery-slim.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup_1.js"></script>
  </body>
</html>
