<?php
session_start();
require_once 'Database.php';
//require_once 'webFrame.php';
$choice=$_GET["booksearch"];
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Bookreta - Online Library and Book rent</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/carousel.css" rel="stylesheet">
  </head>

  <body>
         <header>
    <?php
    include 'header.php';
    ?>
    </header> 
      <br>
    <main role="main">
	

              <div class="container marketing">
        <!-- Example row of columns -->
        <div class="row">
<?php
if(!empty($choice))
{
    $sqlquery="Select * from bookinfo where Book_Name like '%".$choice."%' or Author like '%".$choice."%' limit 10";
    $result= $conn->query($sqlquery);
    $num=$result->num_rows;
    if($num==0)
        {
    //echo 'Invalid phone number password combination';
            $flag=1;
            header("Location:error_page");
    
        }
            else {
            while($row = mysqli_fetch_assoc($result)) 
            {
            ?>

        <div class="col-lg-4">
              <h4><?php echo $row['Book_Name'];?></h4>
			<img class="square" src="<?php echo "images/".$row['BookImage'];?>" alt="Generic placeholder image" width="150" height="200">
            <p><?php echo $row['Author'];?></p>            
            <p><form action="order" method="get">
                <input type="hidden" value="<?php echo $row['Book_ID']; ?>" name="hideed">
                <button class="btn btn-primary" type="submit" role="button">Request &raquo;</button>
            </form> 
          </div> 
<?php
                }
    }
    $result->close();
}else
    header("Location:error_page");//.....error 404 page not found
$conn->close();    
?>
                    </div>
      </div>
        <?php
include 'footer.php';
?>
    </main>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="javascript/jquery-slim.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup.js"></script>
  </body>
</html>