<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="index.php" style="font-family: Papyrus">Bookreta</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">  
          <li class="nav-item">
            <a class="nav-link" href="Fiction">Fiction <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="Horror">Horror</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="History">History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Academic">Academic</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="Comics">Comics</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="pricing">Membership</a>
          </li>
          <!--<li class="nav-item">
            <a class="nav-link" href="#">Request</a>
          </li>-->
          <?php
            if(isset($_SESSION["Name"]))
            {    
          ?>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION["Name"]?></a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                  <a class="dropdown-item" href="newProfile">Profile</a>
                  <!--<a class="dropdown-item" href="settings.php">Settings</a>-->
              <a class="dropdown-item" href="destroy">Logout</a>
            </div>
          </li>
          
          <?php
            }
          else
          {
           ?>
          <li class="nav-item active">
              <a class="nav-link" href="Login">Login</a>
          </li>
          <?php
          }
          ?>
        </ul>
          <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <form method="get" class="signin" action="searchPage.php">
      <input id="booksearch" name="booksearch" value="" type="text" autocomplete="off" placeholder="Search your book in our library" onkeyup="showHint(this.value)" >
  <div id="livesearch"></div>
  </form>

</div>
          <span style="font-size:30px;cursor:pointer" onclick="openNav()"><img src="search-icon-png-27.png" height="30" width="30"></span>
      </div>
    </nav>
	<!--Search form--------------
        <div id="login-box" class="login-popup">
        <a href="#" class="close"><img src="close_pop.png" title="Close Window" alt="Close" /></a>
        <form method="get" class="signin" action="searchPage.php">
                <fieldset class="textbox">
            	<label class="username">
                    <input id="booksearch" name="booksearch" value="" type="text" autocomplete="off" placeholder="Search your book in our library" onkeyup="showHint(this.value)">
                    
                </label>
                
                </fieldset>
            <div id="livesearch"></div>
          </form>
		</div>-->
        <script>
            function abcd(str)
            {
                alert(str);
            }
            function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
        </script>