<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php	
if(isset($_POST['inputPhone'])){
    $filename =filter_input(INPUT_POST,"inputPhone",FILTER_SANITIZE_NUMBER_INT);
    //echo $filename;
}
if(isset($_POST['inputFName'])){
    $fname = filter_var($_POST['inputFName'],FILTER_SANITIZE_STRING);
    //echo $fname;
}
if(isset($_POST['inputLName'])){
    $lname = filter_input(INPUT_POST,"inputLName",FILTER_SANITIZE_STRING);
}
if(isset($_POST['inputEmail'])){
    $mail= filter_var($_POST['inputEmail'],FILTER_SANITIZE_EMAIL);
    if(filter_var($mail,FILTER_VALIDATE_EMAIL))
    {
        //echo $mail;
    }
    //else
        //echo 'Baaaal';
}
//if(isset($_POST['inputAddress'])){
 //   $address =filter_var($_POST['inputAddress']);
//}
//echo $address."\n";
//echo $filename;
//echo $fname;
//echo $lname;
//echo $mail;
//header("Location: Login.php");
if(strlen($filename)==10)
{
require "Database.php";
//echo $filename;
// Authorisation details.
        $username = "swarnajit.adhikary@yahoo.in";
	$hash = "785d12695cad87630211005397695fa8f0bd6d8238492a97de267dc8e6dde7f0";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";
        $checksql="select fname from people where phone='".$filename."'";
        $checkresult= $conn->query($checksql);
        $num1=mysqli_num_rows($checkresult);
        if($num1==0)//.................check if the order is given in the same month
        {
	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "91".$filename; // A single number or a comma-seperated list of numbers
        $userid="A".rand(10, 20)."Z". rand(10, 99);
	$password= "X".rand(1000, 9909)."U". rand(1000, 9999);
	$encrypted_password=md5($password);
        $message = "Your auto generated password is ".$password.". Please change it after logging in.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".
	$hash."&message=".$message."&sender=".
	$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch); 
        //echo $result;
        //echo 'Sent auto generated sms to '.$filename.". Please change it after logging in and do not share the password";
        $sqlquery="insert into people (user_id,fname,address,phone,lname,password) values ('$userid','$fname','$address','$filename','$lname','$encrypted_password')";
        $result= $conn->query($sqlquery);
        if($result==TRUE)
            echo 'We will send auto generated sms to '.$filename." after funding. Password is '".$password."'. Please change it after logging in and do not share the password";
        }
        else
            echo 'Your number is already registered, Please login with your password';
}
else
echo 'Invalid phone number';
?>