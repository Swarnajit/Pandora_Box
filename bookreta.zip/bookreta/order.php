<?php
session_start();
//$choice=$_GET["hideed"]; //value comes from videos.php
//$newchoice=$_SESSION["id"];
//echo $newchoice."\n";
include 'order_handle.php';
//$user=$_SESSION["id"];
          if(strlen($choice1)==6)
          {
              
              /*I don't know why I'm using this, but it's there.*/
               if($num==0)         
                {
                   header("Location:error_page");//............ divert to 404 page not found
                    exit;

                }
              /*---------------------------------------------*/  
                else
                {
    while($row = mysqli_fetch_assoc($result)) 
    {
    ?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>About <?php  echo $row['Book_Name'];?></title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/navbar.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/blog.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
  </head>

  <body>
    <div class="container marketing">
        <?php
        include 'header.php';
        ?>
        <br>
        <br>
        <br>
        

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading"><?php  echo $row['Book_Name'];
        $_SESSION["book"]=$row['Book_Name'];
        $_SESSION["bookimage"]=$row['BookImage'];?>
                <br><span class="text-muted"><?php echo $row['Author'];?></span></h2>
            <p class="lead"><?php bookread($row['About']);?></p>
          </div>
          <div class="col-md-5">
              <img class="featurette-image img-fluid mx-auto" src="<?php echo "images/".$row['BookImage'];?>" alt="<?php  echo $row['Book_Name']?>">
            <p><form action="request_book" method="post">
                <input type="hidden" value="<?php echo base64_encode($row['Book_ID']);?>" name="hideed">
                <?php
            if(isset($_SESSION["Name"]))
            {    
          ?>
                <input type="hidden" value="<?php echo $_SESSION["id"];?>" name="pagla">
            <?php
            }
            ?>
                <button class="btn btn-primary" type="submit" role="button">Request &raquo;</button>
            </form> 
          </div>
        </div>   
      <?php
    }   
    }    
          }
          else {
              header("Location: error_page");////............ divert to 404 page not found
              //echo 'Hacking attempt';
              //echo $choice1;
          }
              
?>
        </div><!-- /.blog-sidebar -->


   <!-----------Footer---------->
   <?php
include 'footer.php';
function bookread($str)
{
    $file = fopen("About/".$str,"r");

while(! feof($file))
  {
  echo fgets($file). "<br />";
  }

fclose($file);
}
?>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="JS/jquery.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>

  </body>
</html>

