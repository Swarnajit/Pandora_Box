<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Password Recovery</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
      <form class="form-signin" action="recoverySms.php" method="post" enctype="multipart/form-data">
            <img class="mb-4" src="images/Graphicloads-Colorful-Long-Shadow-Book.ico" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">Password Recovery</h1>
        <label for="inputPassword" class="sr-only">Phone Number</label>
        <input id="inputEmail" name="number" class="form-control" placeholder="Phone Number" required>
        <br>
        <button class="btn btn-lg btn-primary btn-block" type="submit" >Get OTP</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2017-2018</p>
        <p class="mt-5 mb-3 text-muted" id="result"></p>
      </form>   
  </body>
</html>

