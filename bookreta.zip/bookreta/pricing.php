<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/Graphicloads-Colorful-Long-Shadow-Book.ico">

    <title>Bookreta - Subscription Charge</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/pricing.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <style>
table {
    font-family: arial, sans-serif;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 18px;
}


</style>
  </head>

  <body>
    <header>
    <?php
    session_start();
    include 'Database.php';
    include 'header.php';
    if(isset($_SESSION["id"]))
    {
    $choice=$_SESSION["id"]; 
    $sqlquery="Select fname,lname,address,phone,plan from people where user_id='".$choice."'";
    $result= $conn->query($sqlquery);
    $num=mysqli_num_rows($result);
    ?>
    </header>
      <br>
     <div class="modal fade" id="passwordmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            
            <h4 class="modal-title" id="modalStatus" style="color:black">Billing Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

        </div>
          <form action="pay.php" method="post">  
        <div class="modal-body">
              
         <?php
             if($num!=0)
              {
                  while($row= mysqli_fetch_assoc($result))
                    {
         ?>
            <table>
  <tr>
    <td>Name</td>
    <td><input style="border:none" readonly name="name" value="<?php   echo $row['fname']." ".$row['lname'];?>"></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><textarea style="border:none;resize: none" readonly><?php   echo $row['address'];?></textarea></td>
  </tr>
  <tr>
    <td>Phone</td>
    <td><input style="border:none" readonly name="phone" value="<?php   echo $row['phone'];?>"></td>
    
  </tr>
  <tr>
    <td>Choose Plan</td>
    <td colspan="2"><div class="form-group">
  <select class="form-control" id="sel1" name="product_price">
    <option value="250">Rs.250 for 3 months</option>
    <option value="450">Rs.450 for 6 months</option>
    <option value="200">Rs.200 for 1 month</option>
    <option value="550">Rs.550 for 3 months</option>
    <option value="900">Rs.900 for 6 months</option>
    <option value="350">Rs.350 for 1 month</option>
    <option value="950">Rs.950 for 3 months</option>
    <option value="1500">Rs.1500 for 6 months</option>
  </select>
</div></td>
  </tr>
</table>
         <!--   Name: <p><?php   echo $row['fname']." ".$row['lname'];?></p>
        <input id="newPhone" name="newPhone" class="form-control" placeholder="New Phone" required onkeyup="checkPhone();"><br>
        <input id="OTP" name="OTP" type="password" hidden class="form-control" placeholder="Put OTP here" autocomplete="off" required>-->
        <?php
                    }
              }
        ?>
                
                <?php
                
    }
        ?>
        </div>
        <div class="modal-footer">
            <button type="submit" class="close" id="abcd">Confirm</button>
        </div>
          </form>
      </div>
      
    </div>
  </div><!-- UpdateModal --> 
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">Pricing</h1>
          </div>

    <div class="container theme-showcase">
      <div class="card-deck mb-3 text-center">
        <div class="card mb-4 box-shadow">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Turtle</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.250/3 mo</small></h1>
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.450/6 mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>1 book a Month</li>
              <li>Delivery in 3 days</li>
              <li>No Hidden Charges</li>
              <li>No Late fee</li>
            </ul>
            
          </div>
        </div>
        <div class="card mb-4 box-shadow">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Rabbit</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.200/mo</small></h1>
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.550/3 mo</small></h1>
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.900/6 mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>2 books a Month</li>
              <li>Delivery in 3 days</li>
              <li>No Hidden Charges</li>
              <li>No Late fee</li>
              <li>Bi-weekly Delivery</li>
              <li>1 book per delivery</li>
            </ul>
            
          </div>
        </div>
        <div class="card mb-4 box-shadow">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Cheetah</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.350/mo</small></h1>
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.950/3 mo</small></h1>
            <h1 class="card-title pricing-card-title"><small class="text-muted">Rs.1500/6 mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>4 books a Month</li>
              <li>Delivery in 3 days</li>
              <li>No Hidden Charges</li>
              <li>No Late fee</li>
              <li>Bi-weekly Delivery</li>
              <li>2 books per delivery</li>
            </ul>
            
          </div>
        </div>
      </div>
        <?php
        if(isset($_SESSION["Name"]))
            {
            ?>
               <button type="button" class="btn btn-lg btn-block btn-primary" data-toggle="modal" data-target="#passwordmodal">To Payment Gateway</button>
        <?php
            }
              else
              {
        ?>          
               <button type="button" class="btn btn-lg btn-block btn-primary">Please Login or Signup</button>
<?php
              }
        include 'footer.php';
?>
    </div>
      


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="javascript/jquery-slim.min.js"><\/script>')</script>
    <script src="javascript/popper.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="javascript/holder.min.js"></script>
    <script src="javascript/backup2.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
