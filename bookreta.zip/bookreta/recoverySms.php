<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php	
include 'Database.php';
if(isset($_POST['number'])){
    $filename =filter_input(INPUT_POST,"number",FILTER_SANITIZE_NUMBER_INT);
    echo $filename;
}
if(strlen($filename)==10)
{
//echo $filename;
// Authorisation details.
        $username = "swarnajit.adhikary@yahoo.in";
	$hash = "785d12695cad87630211005397695fa8f0bd6d8238492a97de267dc8e6dde7f0";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";
        $checksql="select fname from people where phone='".$filename."'";
        $checkresult= $conn->query($checksql);
        $num1=mysqli_num_rows($checkresult);
        if($num1!=0)//.................check if the order is given in the same month
        {
	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "91".$filename; // A single number or a comma-seperated list of numbers
        $userid="A".rand(10, 20)."Z". rand(10, 99);
	$password= "X".rand(1000, 9909)."U". rand(1000, 9999);
	$encrypted_pass=md5($password);
        $message = "Your auto generated password is ".$password.". Please change it after logging in.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".
	$hash."&message=".$message."&sender=".
	$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch); 
        //echo $result;
        //echo 'Sent auto generated sms to '.$filename.". Please change it after logging in and do not share the password";
        $sqlquery="update people set password='".$encrypted_pass."' where phone='".$filename."'";
        //echo 'Sent auto generated sms to '.$filename."   ".$password.".Please change it after logging in and do not share the password";
        $result= $conn->query($sqlquery);
        if($result==TRUE)
            echo 'Sent auto generated sms to '.$filename."   ".$password.".Please change it after logging in and do not share the password";
        }
        else
            echo 'Your number is not in our database, Please register';
}
else
echo 'Invalid phone number';
?>